function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
function clicked() {
 var pChanged= document.getElementById("clicked");
 pChanged.button.clicked= "#A81872";
}
